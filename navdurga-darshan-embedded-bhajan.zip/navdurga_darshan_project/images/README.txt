नवदुर्गा चित्र निर्देश

हर देवी का अपना चित्र यहाँ रखें, JPG फ़ॉर्मेट में। फ़ाइल नाम ठीक ऐसे रखें:
maa-shailputri.jpg
maa-brahmacharini.jpg
maa-chandraghanta.jpg
maa-kushmanda.jpg
maa-skandamata.jpg
maa-katyayani.jpg
maa-kalaratri.jpg
maa-mahagauri.jpg
maa-siddhidatri.jpg

चित्र किसी भरोसेमंद/अनुमति-प्राप्त स्रोत से लें। फ़ाइल नाम lowercase रखें। जब तक चित्र नहीं रखे जाते, वेबसाइट पर सुंदर अस्थायी placeholder दिखेगा।
